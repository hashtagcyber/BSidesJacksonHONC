#Baseline Logger/Alert script for Bro.
#Requires baseline.data file to exist in same directory as the script.This is the file you need to update in order to make the script work.
#You need the notice module loaded in order to actually get the logs. 
#Running from cli using bro baseline.bro -r <pcap file> will test your configuration against a pcap, but alerts will go to the notice.log in your current directory. For testing during development, I used this baseline.data file and the shellshock exploit pcap from security onion (/opt/samples/shellshock/exploit.pcap)
#Consider copying this script to /opt/bro/share/bro/policy/misc/baselinereport.bro and adding "@load misc/baselinereport" to your /opt/bro/share/bro/site/local.bro file
#Also checkout bro_agent for SGUIL that will allow you to push bro's notice.logs into SGUIL
#Written By @HashtagCyber, originally for a workshop I presented @BSidesJackson 2016.
#Shoutout to @Killswitch_GUI for convincing my to start speaking, and @Chirontech for supporting me.
